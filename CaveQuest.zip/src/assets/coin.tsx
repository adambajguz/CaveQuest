<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="coin" tilewidth="64" tileheight="64" tilecount="4" columns="4">
 <image source="coin.png" trans="ffffff" width="256" height="64"/>
</tileset>
