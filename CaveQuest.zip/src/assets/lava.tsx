<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="lava" tilewidth="64" tileheight="64" tilecount="3" columns="3">
 <image source="lava.png" width="192" height="64"/>
</tileset>
