<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="cave" tilewidth="32" tileheight="32" tilecount="100" columns="20">
 <image source="cave.png" trans="ffffff" width="640" height="160"/>
</tileset>
